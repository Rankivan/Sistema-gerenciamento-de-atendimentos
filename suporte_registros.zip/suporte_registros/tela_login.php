

<?php

 $erro_valida =  isset ($_GET ['erro']) ? $_GET ['erro']: 0 ;


?>



<!DOCTYPE html>
 <html lang="pt-br">

 <head>
   <meta charset="utf-8">
  <title> Suporte </title>


        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
  
        <link href="css/bootstrap.min.css" rel="stylesheet">

        <link rel="stylesheet" type="text/css" href=" INSERIR LINK .css">

        <meta name="viewport" content="width=device-width, initial-scale=0.8">



</head>

<!--___________________________________________________________________________________-->
<!--___________________________________________________________________________________-->

<body style="background-color: #d0d3e6">


  <div style="">

    <!--vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv-->


    <!--#######################################__HOME__########################################-->


    <div align="center" style="margin-top: 100px;"> 


     <img src="imagens/conteudo/denisoft.png" style="width: 320px ; height: 100px ;">

   </div>


   <form method="post" action="back_end/validacoes/valida_login.php">

    <div align="center" >
      <div class="form-group col-md-4">
        <div align="left">
          <label for="exampleInputEmail1"><h5>Login</h5></label>
        </div>
        <input  name="usuario" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" style="height: 50px">

      </div>
      <div class="form-group col-md-4">
        <div align="left">
          <label for="exampleInputPassword1"><h5>Senha</label>
          </div>
          <input type="password" name="senha" class="form-control" id="exampleInputPassword1" style="height: 50px">
        </div>
        <div class="form-group form-check">
          <input  type="checkbox" class="form-check-input" id="exampleCheck1" >

          <label class="form-check-label" for="exampleCheck1">Lembrar registro</label>
        </div>
        <div class="form-group" >
          <button type="submit" style="width: 430px" class="btn btn-primary btn-lg btn-block">Entrar</button>
        </div>
      </div>

    </form>

    <!--#######################################__  __########################################-->


    <!--^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^-->

  </div>

</body>

<!--___________________________________________________________________________________-->
<!--___________________________________________________________________________________-->

</html>




                <?php if ($erro_valida==1){ ?>
                    <script type="text/javascript">
                      $(document).ready(function(){ //Abrir a modal pelo JS
                      $("#mensgem_de_erro_valida").modal();
                      });
                    </script>

                <?php }  ?> 
            

<!-- Modal -->
<div class="modal fade" id="mensgem_de_erro_valida" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Retorno</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
       <h5 style="color: #ae0000">Usuário ou senha não estão corretos!</h5>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>