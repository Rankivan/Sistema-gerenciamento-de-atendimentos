
<?php

 $msg_cadastro_atend =  isset ($_GET ['msg_cadastro_atend']) ? $_GET ['msg_cadastro_atend']: 0 ;
 $msg_edicao_atend   =  isset ($_GET ['msg_edicao_atend']) ? $_GET ['msg_edicao_atend']: 0 ;
 $excluir_atend   =  isset ($_GET ['excluir_atend']) ? $_GET ['excluir_atend']: 0 ;
 $msg_exclusao_atend   =  isset ($_GET ['msg_exclusao_atend']) ? $_GET ['msg_exclusao_atend']: 0 ;

?>







<!--#######################################__HOME__########################################-->

  <div id="eventos_diversos_js">
  <!--___________-->

 <div style="padding: 10px;">
   <div class="row">
     <div class="col-sm-6">
       <div class="card">
        <h5 class="card-header"> Atender </h5>
        <a href="#" style="color: black" type="button"data-toggle="modal" data-target="#form_atendimento"> <div class="card-body">
          
          <p class="card-text">Realize um novo atendimento</p>
          <img src="imagens/conteudo/suporte_2.png" style="width: 40px ; height: 40px ;">
        </div></a>
      </div>
    </div>
    
    <div class="col-sm-6">
     <div class="card">
      <h5 class="card-header"> 

                Pesquisar por:
                <a style="color: blue"  type="button" onclick="pesquisa_nome();" >Nome</a> |
                <a style="color: blue"  type="button" onclick="pesquisa_empresa();">Empresa</a></h5> 

      <div class="card-body">     
       <form method="post">
        <div class="input-group mb-2">
          <div class="input-group-prepend">
           <div class="input-group-text"> 
              <button  type="submit" name=""> <img src="imagens/conteudo/procurar.png" style="width: 40px ; height: 40px ;" ></button></div>
         </div>

        <div id="buscar_nome">
         <input id="buscar_id_habilit" name="buscar_nome" style="height: 70px;" type="text" class="form-control" placeholder="POR CLIENTE" disabled="">
        </div>
        

        <div id="buscar_empresa">
         <input  id="buscar_empresa_habilit"  name="buscar_empresa" style="height: 70px;" type="text" class="form-control" placeholder="  POR EMPRESA" disabled=""> 
        </div>

       </div>
      </form>
     </div>
   </div>
 </div>

</div> <br>


 <!--####################################_MENSAGENS DE ERRO_######################################-->
  
<div>
  <button  type="button" class="btn btn-primary" data-toggle="modal" data-target="#modal_pendentes" style="background-color: #af0000; color: white"><h5>Pendentes</h5></button>
</div><br>





<!--_________________________________________________________________________________________-->

  <!--#######################################__TABELA__########################################-->
  <div class=" table table-responsive table-sm" >
    <table class="table table-striped">
      <thead>
        <tr>
          <th scope="col">N°</th>
          <th scope="col">Nome</th>
          <th scope="col">Empresa</th>
          <th scope="col">Situação</th>
          <th scope="col">Data</th>
          <th scope="col"> Visualizar </th>

        </tr>
      </thead>
      <tbody>




 <?php                  
               
               @$buscar_empresa = '%'.$_POST['buscar_empresa'].'%';
               @$buscar_nome = '%'.$_POST['buscar_nome'].'%';
               


                  //_____________________________PAGINAÇÂO________________________________

                //Arquivo que criará o sistema de páginação do projeto
                //Envio do número da página via GET
                $pagina_atual_atend = filter_input(INPUT_GET,'pagina_atend', FILTER_SANITIZE_NUMBER_INT); 
                //Se ela for vazia será a página 1, senão é igual ao número via GET
                $pagina_atend = (!empty($pagina_atual_atend)) ? $pagina_atual_atend : 1;
                //Definir número de páginas por número de registros
                $quant_de_resultado_por_pag_atend = 10;
                //Cálculo para o início da visualização
                $inicio_list_atend = ($quant_de_resultado_por_pag_atend * $pagina_atend) - $quant_de_resultado_por_pag_atend;


              //#############################################################################################


               

              //##################################################################################

               if (isset ($_POST['buscar_nome']) != '') {
                $consulta_tab_atend = $pdo->prepare("SELECT * from atendimentos_suporte where nome_atend LIKE :nome_atend ORDER BY id_atend DESC limit $inicio_list_atend, $quant_de_resultado_por_pag_atend"); 
                $consulta_tab_atend->bindValue(":nome_atend",$buscar_nome);
                $consulta_tab_atend->execute();
                # code...
              }

               if (isset ($_POST['buscar_empresa']) != '') {

                $consulta_tab_atend = $pdo->prepare("SELECT * from atendimentos_suporte where empresa_atend LIKE :empresa_atend ORDER BY id_atend DESC limit $inicio_list_atend, $quant_de_resultado_por_pag_atend"); 
                $consulta_tab_atend->bindValue(":empresa_atend",$buscar_empresa);
                $consulta_tab_atend->execute();
                # code...
              }

            
              /* if (isset ($_POST['buscar_empresa'])  != '') {
                $consulta_tab_atend = $pdo->prepare("SELECT * from atendimentos_suporte where empresa_atend LIKE :empresa_atend ORDER BY id_atend DESC limit $inicio_list_atend, $quant_de_resultado_por_pag_atend"); 
                $consulta_tab_atend->bindValue(":empresa_atend",$buscar_atendimento);
                $consulta_tab_atend->execute();
                # code...
              }*/


              if (isset  ($_POST['buscar_nome']) == "" && @($_POST['buscar_empresa']) == ""  ){
                //Comando de consulta no banco de dados
                $consulta_tab_atend = $pdo->query("SELECT * from atendimentos_suporte ORDER BY id_atend DESC limit  $inicio_list_atend, $quant_de_resultado_por_pag_atend");
              }




                $dados_tab_atend = $consulta_tab_atend->fetchAll(PDO::FETCH_ASSOC);
              //Este código conta e repassa as linhas da tabela "usuarios"
              //É um cópigo padrão da estrutura "PDO"
              for ($i=0; $i < count($dados_tab_atend); $i++){
              foreach ($dados_tab_atend[$i] as $key => $value) {
                  //echo $key."-".$value."<br>"; //Apresenta todos os valores das colunas
                  # code...
                }
                //echo $dados[$i]['nome']."<br><br>";
                $id_atend              = $dados_tab_atend[$i]['id_atend'];
                $nome_atend            = $dados_tab_atend[$i]['nome_atend'];
                $empresa_atend         = $dados_tab_atend[$i]['empresa_atend'];
                $telefone_atend        = $dados_tab_atend[$i]['telefone_atend'];
                $obs_atend             = $dados_tab_atend[$i]['obs_atend'];
                $situacao_atend        = $dados_tab_atend[$i]['situacao_atend'];
                $cadastrante_atend     = $dados_tab_atend[$i]['cadastrante_atend'];
                $momento_atend         = $dados_tab_atend[$i]['momento_atend'];
              

                //$linhas = count($dados);//conta quantos registros  por página
    
                  ?>

            <?php if ($situacao_atend == "Resolvido") {
              # code...
            ?>
                 <tr class="table-success">
            <?php } ?>

            <?php if ($situacao_atend == "Em aberto") {
              # code...
            ?>
                 <tr class="table-danger">
            <?php } ?>

              <?php if ($situacao_atend == "Outro") {
              # code...
            ?>
                 <tr class="table-warning">
            <?php } ?>


                <th scope="row"><?php echo utf8_encode($id_atend); ?></th>
                  <td><?php echo ($nome_atend); ?></td>
                  <td><?php echo ($empresa_atend); ?></td>   
                  <td><h6><?php echo ($situacao_atend); ?></h6>
                   </td>
                  <td><?php echo ($momento_atend); ?></td>
                <td>
                  <a href="index.php?funcao=editar_atend&id_atend=<?php echo $id_atend ?>"><img src="imagens/conteudo/olho.png" style="width: 20px ; height: 20px "></a>

                </td>
              </tr>

            <?php }  ?>

        </tbody>
      </table>
    </div>


                <?php   $data_base_atend = new db ();
                 $link_atend = $data_base_atend->conecta_mysqli(); 

                //Iniciando a paginação e contando os usuários do banco de daodos
                  //Somando a quantidade de registros no bd
                  $result_listagem_atend = "SELECT count(id_atend) as resultado_atend FROM atendimentos_suporte"; 
                  $resultado_qtd_rgist_atend = mysqli_query($link_atend,$result_listagem_atend);
                  $quantidade_total_rgist_atend = mysqli_fetch_assoc($resultado_qtd_rgist_atend);

                //Quantidade de páginas que serão apresentadas nos links
                  $quantidade_paginas_atend = ceil($quantidade_total_rgist_atend['resultado_atend'] / $quant_de_resultado_por_pag_atend);
                //Limitar o número do link de paginação
                  $limite_links_maximo_atend = 3;

                 ?>




     <?php  /*Comando php para puxar os dados referente ao id
       e executar a edição.*/

     
    if(isset($_GET['funcao'])=='editar_atend'){
     $id_atend_edit = $_GET['id_atend']; //Passagem de dados via URL por meio GET
  
       //Recuperar dados do usuario a ser editado

      $resultado_consulta_atend = $pdo->query ("select * from atendimentos_suporte where id_atend = '$id_atend_edit'");
       $dados_atend_edit = $resultado_consulta_atend->fetchAll(PDO::FETCH_ASSOC);

       $id_atend          = $dados_atend_edit[0]['id_atend'];
       $nome_atend        = $dados_atend_edit[0]['nome_atend'];
       $empresa_atend     = $dados_atend_edit[0]['empresa_atend'];
       $telefone_atend    = $dados_atend_edit[0]['telefone_atend'];
       $obs_atend         = $dados_atend_edit[0]['obs_atend'];
       $situacao_atend    = $dados_atend_edit[0]['situacao_atend'];
       $cadastrante_atend = $dados_atend_edit[0]['cadastrante_atend'];
       $momento_atend     = $dados_atend_edit[0]['momento_atend'];
      


   /*
    $objDb = new db ();
    $link =  $objDb->conecta_mysqli();

    $id = filter_input(INPUT_GET,'id',FILTER_SANITIZE_NUMBER_INT);

    $result_rato = "SELECT * FROM bd_rato WHERE id = '$id'";
    $resultado_rato = mysqli_query ($link,$result_rato);
    $row_rato = mysqli_fetch_assoc($resultado_rato);*/
  
?>

    <script type="text/javascript">


       $(document).ready(function(){ //Abrir a modal pelo JS
        $("#modal_editar_atend").modal();
      });
   </script>
<?php }?>



















<div align="center">

 <?php
          echo "<a class='btn btn-secondary' href='index.php?pagina_atend=1'>Primeira</a> ";//Primeira página
          for ($pagina_anterior_atend = $pagina_atend -  $limite_links_maximo_atend; $pagina_anterior_atend <= $pagina_atend-1 ; $pagina_anterior_atend ++  ) { 

            if ($pagina_anterior_atend >= 1 ) {
              echo "<a class='btn btn-primary' href='index.php?pagina_atend=$pagina_anterior_atend'>$pagina_anterior_atend</a> ";
                } //Conta uma página para trás e para frente
              }
          echo "<a class='btn btn-danger' href='index.php?pagina_atend=$pagina_atend'> $pagina_atend</a> ";//Página atual

          for ($pagina_posterior_atend = $pagina_atend+ 1; $pagina_posterior_atend <= $pagina_atend + $limite_links_maximo_atend ; $pagina_posterior_atend ++  ) { 

            if ($pagina_posterior_atend <= $quantidade_paginas_atend ) {
              echo "<a class='btn btn-primary' href='index.php?pagina_atend=$pagina_posterior_atend'>$pagina_posterior_atend</a> ";
                } 
              }

          echo "<a class='btn btn-secondary' href='index.php?pagina_atend=$quantidade_paginas_atend'>Última</a> ";//ultima página
          ?>
<hr>
 <h5>Total de registros = <y><?php echo $quantidade_total_rgist_atend['resultado_atend']; ?></h5></y>
</div>





</div>


<?php include ($modais_atend); ?>
<?php include($modal_pendentes)  ?>