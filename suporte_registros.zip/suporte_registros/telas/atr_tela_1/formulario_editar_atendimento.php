


<div>

                  <div class="form-row">
                    <div class="form-group col-md-4">
                      <label >Nome </label>
                      <input value="<?php echo ($nome_atend);  ?>" id="nome_atend_edit" name="nome_atend_edit" type="text" class="form-control" required="" placeholder="Digite um nome" disabled>
                    </div>
                    <div class="form-group col-md-4">
                      <label >Empresa</label>

                      <input value="<?php echo  ($empresa_atend);  ?>" id="empresa_atend_edit" name="empresa_atend_edit" type="text" class="form-control" required="" placeholder="Digite a empresa" disabled>
                 
                    </div>



                   <div class="form-group col-md-4">
                      <label >Telefone</label>

                      <input value="<?php echo  ($telefone_atend);  ?>" id="telefone_atend_edit" name="telefone_atend_edit" type="text" class="form-control" required="" placeholder="Telefone para contato" disabled >
                 
                    </div>
                  

                   <div class="form-group col-md-4">
                      <label >Observações</label>

                      <textarea id="obs_atend_edit" name="obs_atend_edit"  type="text" class="form-control" required="" placeholder="Ocorrencia" disabled><?php echo  ($obs_atend); ?></textarea>
                 
                    </div>
                  

                      <div class="form-group col-md-4">
                            <label >Situação</label>
                             <select id="situacao_atend_edit"  name="situacao_atend_edit" class="form-control" required="" id=""  onchange="" disabled >
                         
                              <option value="<?php echo  ($situacao_atend);  ?>"> <?php echo  ($situacao_atend)  ?></option>
                              <option value="Resolvido"> Resolvido </option>
                              <option value="Em aberto">Em aberto</option>
                              <option value="Outro">Outro</option>

                            </select>
                      </div>


                     <div class="form-group col-md-4">
                      <label >Data do atendimento</label>

                      <input value="<?php echo  ($momento_atend);  ?>" type="text" class="form-control" required="" placeholder="Data do atendimento" disabled>
                 
                    </div>
                  


               </div>

                         <input type="hidden" value="<?php echo  ($cadastrante_atend)  ?>" id="cadastrante_atend_edit" name="cadastrante_atend_edit" disabled >

                          <input type="hidden" value="<?php echo ($id_atend)  ?>" id="id_atend_edit" name="id_atend_edit"  >
                
    </div>
