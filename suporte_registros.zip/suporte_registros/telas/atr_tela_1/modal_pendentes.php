






<!-- Modal -->
<div class="modal fade" id="modal_pendentes" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog modal-xl modal-dialog-scrollable">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="staticBackdropLabel">Pendentes</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
      





<!--_________________________________________________________________________________________-->

  <!--#######################################__TABELA__########################################-->
  <div class=" table table-responsive table-sm" >
    <table class="table table-striped">
      <thead>
        <tr>
          <th scope="col">N°</th>
          <th scope="col">Nome</th>
          <th scope="col">Empresa</th>
          <th scope="col">Situação</th>
          <th scope="col">Data</th>
          <th scope="col"> Visualizar </th>

        </tr>
      </thead>
      <tbody>




 <?php     
              
     

            
              /* if (isset ($_POST['buscar_empresa'])  != '') {
                $consulta_tab_atend = $pdo->prepare("SELECT * from atendimentos_suporte where empresa_atend LIKE :empresa_atend ORDER BY id_atend DESC limit $inicio_list_atend, $quant_de_resultado_por_pag_atend"); 
                $consulta_tab_atend->bindValue(":empresa_atend",$buscar_atendimento);
                $consulta_tab_atend->execute();
                # code...  ORDER BY id_atend DESC
              }*/


              if (isset ($_POST['buscar_situacao']) == "" ){
                //Comando de consulta no banco de dados
                $consulta_tab_atend = $pdo->query("SELECT * from atendimentos_suporte where situacao_atend = 'Em aberto' ");
              }


                $dados_tab_atend = $consulta_tab_atend->fetchAll(PDO::FETCH_ASSOC);
              //Este código conta e repassa as linhas da tabela "usuarios"
              //É um cópigo padrão da estrutura "PDO"
              for ($i=0; $i < count($dados_tab_atend); $i++){
              foreach ($dados_tab_atend[$i] as $key => $value) {
                  //echo $key."-".$value."<br>"; //Apresenta todos os valores das colunas
                  # code...
                }
                //echo $dados[$i]['nome']."<br><br>";
                $id_atend              = $dados_tab_atend[$i]['id_atend'];
                $nome_atend            = $dados_tab_atend[$i]['nome_atend'];
                $empresa_atend         = $dados_tab_atend[$i]['empresa_atend'];
                $telefone_atend        = $dados_tab_atend[$i]['telefone_atend'];
                $obs_atend             = $dados_tab_atend[$i]['obs_atend'];
                $situacao_atend        = $dados_tab_atend[$i]['situacao_atend'];
                $cadastrante_atend     = $dados_tab_atend[$i]['cadastrante_atend'];
                $momento_atend         = $dados_tab_atend[$i]['momento_atend'];
              

                //$linhas = count($dados);//conta quantos registros  por página
    
                  ?>

            <?php if ($situacao_atend == "Resolvido") {
              # code...
            ?>
                 <tr class="table-success">
            <?php } ?>

            <?php if ($situacao_atend == "Em aberto") {
              # code...
            ?>
                 <tr class="table-danger">
            <?php } ?>

              <?php if ($situacao_atend == "Outro") {
              # code...
            ?>
                 <tr class="table-warning">
            <?php } ?>


                <th scope="row"><?php echo utf8_encode($id_atend); ?></th>
                  <td><?php echo ($nome_atend); ?></td>
                  <td><?php echo ($empresa_atend); ?></td>   
                  <td><?php echo ($situacao_atend); ?>
                   </td>
                  <td><?php echo ($momento_atend); ?></td>
                <td>
                  <a href="index.php?funcao=editar_atend&id_atend=<?php echo $id_atend ?>"><img src="imagens/conteudo/olho.png" style="width: 20px ; height: 20px "></a>

                </td>
              </tr>

            <?php }  ?>

        </tbody>
      </table>
    </div>















      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Fechar</button>
      </div>
    </div>
  </div>
</div>