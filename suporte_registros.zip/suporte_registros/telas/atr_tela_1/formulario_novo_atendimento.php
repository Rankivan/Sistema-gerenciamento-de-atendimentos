  




  <div>

                  <div class="form-row">
                    <div class="form-group col-md-4">
                      <label >Nome </label>
                      <input name="nome_atend" type="text" class="form-control" required="" placeholder="Digite um nome" >
                    </div>
                    <div class="form-group col-md-4">
                      <label >Empresa</label>

                      <input name="empresa_atend" type="text" class="form-control" required="" placeholder="Digite a empresa" >
                 
                    </div>



                   <div class="form-group col-md-4">
                      <label >Telefone</label>

                      <input name="telefone_atend" type="text" class="form-control" required="" placeholder="Telefone para contato" >
                 
                    </div>
                  

                   <div class="form-group col-md-4">
                      <label >Observações</label>

                      <textarea name="obs_atend"  type="text" class="form-control" required="" placeholder="Ocorrencia"></textarea>
                 
                    </div>
                  

                      <div class="form-group col-md-4">
                            <label >Situação</label>
                             <select  name="situacao_atend" class="form-control" required="" id=""  onchange=""  >
                         
                              <option value=""></option>
                              <option value="Resolvido">Resolvido</option>
                              <option value="Em aberto">Em aberto</option>
                              <option value="Outro">Outro</option>

                            </select>
                      </div>


               </div>

                         <input type="hidden" name="cadastrante_atend" value="<?=$_SESSION['id']?> - <?= $_SESSION['usuario']?>">
                
    </div>
