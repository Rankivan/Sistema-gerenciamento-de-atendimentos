


$("#btn_salvar_atend").hide();
$('#buscar_id_habilit').prop('disabled', false);

function btn_edita_atend (){

$("#btn_salvar_atend").show();
$("#btn_edita_atend").hide();

      $('#nome_atend_edit').prop('disabled', false);
      $('#empresa_atend_edit').prop('disabled', false);
      $('#telefone_atend_edit').prop('disabled', false);
      $('#obs_atend_edit').prop('disabled', false);
      $('#situacao_atend_edit').prop('disabled', false);
      $('#cadastrante_atend_edit').prop('disabled', false);




}




$("#buscar_id_habilit").show();
$("#buscar_empresa_habilit").hide();

function pesquisa_nome (){


	$('#buscar_id_habilit').prop('disabled', false);
	 $('#buscar_empresa_habilit').prop('disabled', true);

    $("#buscar_id_habilit").show();
	$("#buscar_empresa_habilit").hide();
}


function pesquisa_empresa (){

	 $('#buscar_id_habilit').prop('disabled', true);
	 $('#buscar_empresa_habilit').prop('disabled', false);

    $("#buscar_id_habilit").hide();
	$("#buscar_empresa_habilit").show();
	
}


