


<?php 
    require_once("back_end/conexao_bd.php");
     @session_start();

      if(!isset($_SESSION['usuario'])) {
      header('location:tela_login.php');
 }

 ?>


       <!--############# TELA_1 ################-->
       <?php   $tela_1 = 'telas/tela_1.php';  ?>
       <?php   $form_novo_atend = 'telas/atr_tela_1/formulario_novo_atendimento.php';  ?>
       <?php   $formulario_editar_atendimento = 'telas/atr_tela_1/formulario_editar_atendimento.php';  ?>
       <?php   $modais_atend = 'telas/atr_tela_1/modais_atend.php';  ?>
       <?php   $modal_pendentes = 'telas/atr_tela_1/modal_pendentes.php';  ?>







<!DOCTYPE html>
 <html lang="pt-br">

 <head>
   <meta charset="utf-8">
	<title> Suporte </title>


        <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/css/bootstrap.min.css" integrity="sha384-TX8t27EcRE3e/ihU7zmQxVncDAy5uIKz4rEkgIXeMed4M0jlfIDPvg6uqKI2xXr2" crossorigin="anonymous">

        <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js" integrity="sha384-DfXdz2htPH0lsSSs5nCTpuj/zy4C+OGpamoFVy38MVBnE+IbbVYUew+OrCXaRkfj" crossorigin="anonymous"></script>

        <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ho+j7jyWK8fNQe+A12Hb8AhRq26LrZ/JpcUGGOn+Y7RsweNrtN/tE3MoK7ZeZDyx" crossorigin="anonymous"></script>
	
	    <link href="css/bootstrap.min.css" rel="stylesheet">


	    <link rel="stylesheet" type="text/css" href=" INSERIR LINK .css">

	    <meta name="viewport" content="width=device-width, initial-scale=0.8">



</head>

<!--___________________________________________________________________________________-->
<!--___________________________________________________________________________________-->

<body style="background-color: #d0d3e6">

<div>
 <nav class="navbar navbar-light bg-light">
  <span class="">
   <img src="imagens/conteudo/denisoft.png" style="width: 300px ; height: 70px ;">

   <div>
   	<h5 > Usuário = <y style="color: blue"> <?=$_SESSION['id']?> - <?= $_SESSION['usuario']?></y></h5> 
   </div>

  </span>
</nav>
</div>



	

	<div >

		<!--vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv-->


<!--#######################################__HOME__########################################-->

 <?php include($tela_1) ?>


  <!--___________-->
  </div>


   <!--#######################################__  __########################################-->


		<!--^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^-->

	</div>
</body>

<!--___________________________________________________________________________________-->
<!--___________________________________________________________________________________-->

</html>



      <script src ="arquivos_js/tela_1/tela_1_002.js"></script>


       