<?php

   include_once ("../../conexao_bd.php");
   @session_start();


    $id_para_exclusao = filter_input(INPUT_POST,'id_para_exclusao', FILTER_SANITIZE_STRING);


    
  //echo "id =" .  $id_excluir;  //testes para saber se o id está send chamado
  //($_GET["id_excluir"]);


      $data_base_excluir_atend = new db ();
      $link_excluir_atend = $data_base_excluir_atend->conecta_mysqli();   
       $resultado_excluir_atend ="DELETE from atendimentos_suporte where id_atend ='$id_para_exclusao'";
       $resultado_excluir_atend = mysqli_query ($link_excluir_atend,$resultado_excluir_atend);

     if (mysqli_query ($link_excluir_atend,$resultado_excluir_atend)){

       header("location: ../../../index.php?msg_exclusao_atend=2");

       //header("location: ../../../sist_admin/telas_adm/adm.php?acao=usuarios_adm&msg_exclui_usu_erro=1");

    } else { 

    header("location: ../../../index.php?msg_exclusao_atend=1");
        

      }




?>