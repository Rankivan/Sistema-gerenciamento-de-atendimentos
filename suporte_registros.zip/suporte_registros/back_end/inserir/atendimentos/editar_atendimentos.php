



<?php 
   
   include_once ("../../conexao_bd.php");
   @session_start();




      $nome_atend_edit         = filter_input(INPUT_POST,'nome_atend_edit', FILTER_SANITIZE_STRING);
      $empresa_atend_edit      = filter_input(INPUT_POST,'empresa_atend_edit', FILTER_SANITIZE_STRING);
      $telefone_atend_edit     = filter_input(INPUT_POST,'telefone_atend_edit', FILTER_SANITIZE_STRING);
      $obs_atend_edit          = filter_input(INPUT_POST,'obs_atend_edit', FILTER_SANITIZE_STRING);
      $situacao_atend_edit          = filter_input(INPUT_POST,'situacao_atend_edit', FILTER_SANITIZE_STRING);
      $id_atend_edit           = filter_input(INPUT_POST,'id_atend_edit', FILTER_SANITIZE_STRING);
 

    
      /* echo("id: $id_usuario_edit"); 
       echo("nome: $nome");    //TESTES para saber se estão sendo chamadas
       echo("sobrenome: $sobrenome");
       echo("data_nascimento: $data_nascimento");
       echo("telefone: $telefone");
       echo("tipo_usuario: $tipo_usuario");
       echo("adicional_usuario: $adicional_usuario");
       echo("observacoes: $observacoes");
       echo("nivel_acesso: $nivel_acesso");
       echo("e_mail: $e_mail");
       echo("senha: $senha"); 
       echo("cadastrante: $cadastrante"); 
       echo("senha: $senha");  */
            
          
            
              $data_base_edit_atend = new db ();
              $link_edit_atend = $data_base_edit_atend->conecta_mysqli();

              $editar_atend = "UPDATE atendimentos_suporte SET 
              nome_atend        = '$nome_atend_edit', 
              empresa_atend     = '$empresa_atend_edit',
              telefone_atend    = '$telefone_atend_edit',
              obs_atend         = '$obs_atend_edit',
              situacao_atend    = '$situacao_atend_edit'
              WHERE id_atend ='$id_atend_edit'";
             
            //$inserir_usuarios = "INSERT INTO usuarios () VALUES ('','','','','')";

              $resultado_edicao_atend = mysqli_query($link_edit_atend,$editar_atend);
              if(mysqli_affected_rows($link_edit_atend)){

                header("location: ../../../index.php?msg_edicao_atend=1");
              } else {

                header("location: ../../../index.php?msg_edicao_atend=2");
              } 
               //__________________________________________________________________________________________
              //$nome_sessão_cadastro = filter_input(INPUT_POST,'nome', FILTER_SANITIZE_STRING);
              //$_SESSION['nome'] =  $nome_sessão_cadastro;


        

 /*

      $nome               = filter_input(INPUT_POST,'nome', FILTER_SANITIZE_STRING);
      $sobrenome          = filter_input(INPUT_POST,'sobrenome', FILTER_SANITIZE_STRING);
      $data_nascimento    = filter_input(INPUT_POST,'data_nascimento', FILTER_SANITIZE_STRING);
      $telefone           = filter_input(INPUT_POST,'telefone', FILTER_SANITIZE_STRING);
      $tipo_usuario       = filter_input(INPUT_POST,'tipo_usuario', FILTER_SANITIZE_STRING);
      $adicional_usuario  = filter_input(INPUT_POST,'adicional_usuario', FILTER_SANITIZE_STRING);
      $nivel_acesso       = filter_input(INPUT_POST,'nivel_acesso', FILTER_SANITIZE_STRING);
      $observacoes        = filter_input(INPUT_POST,'observacoes', FILTER_SANITIZE_STRING);
      $e_mail             = filter_input(INPUT_POST,'e_mail', FILTER_SANITIZE_STRING);
      $senha              = filter_input(INPUT_POST,'senha', FILTER_SANITIZE_STRING);
      $cadastrante        = filter_input(INPUT_POST,'cadastrante', FILTER_SANITIZE_STRING);

 */

 


?> 