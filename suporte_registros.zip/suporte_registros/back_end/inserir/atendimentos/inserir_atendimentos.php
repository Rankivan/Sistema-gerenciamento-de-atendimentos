

<?php

require_once("../../conexao_bd.php");
 @session_start();


$nome_atend              = filter_input(INPUT_POST,'nome_atend', FILTER_SANITIZE_STRING);
$empresa_atend           = filter_input(INPUT_POST,'empresa_atend', FILTER_SANITIZE_STRING);
$telefone_atend          = filter_input(INPUT_POST,'telefone_atend', FILTER_SANITIZE_STRING);
$obs_atend               = filter_input(INPUT_POST,'obs_atend', FILTER_SANITIZE_STRING);
$situacao_atend          = filter_input(INPUT_POST,'situacao_atend', FILTER_SANITIZE_STRING);
$cadastrante_atend       = filter_input(INPUT_POST,'cadastrante_atend', FILTER_SANITIZE_STRING);


/*
echo "nome: ".$nome_atend."<br>" ;
echo "empresa_atend: ".$empresa_atend."<br>" ;
echo "telefone_atend: ".$telefone_atend."<br>" ;
echo "obs_atend: ".$obs_atend."<br>" ;
echo "situacao_atend: ".$situacao_atend."<br>" ;
echo "cadastrante_atend: ".$cadastrante_atend."<br>" ;

*/



         # code...
       
              $data_base = new db ();
              $link = $data_base->conecta_mysqli();
              
              $inserir_atend = "INSERT INTO atendimentos_suporte
              (nome_atend,
              empresa_atend,
              telefone_atend,
              obs_atend,
              situacao_atend,
              cadastrante_atend,
              momento_atend ) 
              VALUES                                              
              ('$nome_atend',
              '$empresa_atend',
              '$telefone_atend',
              '$obs_atend',
              '$situacao_atend',
              '$cadastrante_atend',
               NOW())";
            //$inserir_usuarios = "INSERT INTO usuarios () VALUES ('','','','','')";

               

              $resultado_registro = mysqli_query($link,$inserir_atend);
              if(mysqli_insert_id($link)){
                 
                header("location: ../../../index.php?msg_cadastro_atend=1");
                 
              } else {
              	 
                header("location: ../../../index.php?msg_cadastro_atend=2");
              }
               //__________________________________________________________________________________________
              //$nome_sessão_cadastro = filter_input(INPUT_POST,'nome', FILTER_SANITIZE_STRING);
              //$_SESSION['nome'] =  $nome_sessão_cadastro;


















?>