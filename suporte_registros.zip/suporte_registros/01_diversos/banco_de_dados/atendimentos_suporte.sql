-- phpMyAdmin SQL Dump
-- version 4.9.4
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 01-Fev-2021 às 10:27
-- Versão do servidor: 5.7.23-23
-- versão do PHP: 7.3.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `tecnob39_sist_boquinha`
--

-- --------------------------------------------------------

--
-- Estrutura da tabela `atendimentos_suporte`
--

CREATE TABLE `atendimentos_suporte` (
  `id_atend` int(32) NOT NULL,
  `nome_atend` varchar(40) NOT NULL,
  `empresa_atend` varchar(40) NOT NULL,
  `telefone_atend` varchar(32) NOT NULL,
  `obs_atend` varchar(400) NOT NULL,
  `situacao_atend` varchar(32) NOT NULL,
  `cadastrante_atend` varchar(32) NOT NULL,
  `momento_atend` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `atendimentos_suporte`
--

INSERT INTO `atendimentos_suporte` (`id_atend`, `nome_atend`, `empresa_atend`, `telefone_atend`, `obs_atend`, `situacao_atend`, `cadastrante_atend`, `momento_atend`) VALUES
(7, 'Everaldo ', 'Discreta calcados', '63 984020719', 'Instalar certificado repassado pelo Paulo. ', 'Resolvido', '1 - ivanrank', '2021-01-14 00:00:00'),
(8, 'magda', 'magda modas', 'nd', 'Auxilio no balanco de estoque', 'Resolvido', '1 - ivanrank', '2021-01-14 00:00:00'),
(9, 'Cleo', 'Dist. Uniao', '63 9215 2782', 'Erro aparece ao converter CFOP. \r\nFoi necessario converter o CFOP', 'Resolvido', '1 - ivanrank', '2021-01-14 00:00:00'),
(10, 'zico', 'levis', 'nd', 'Verificar modificacao ao balanco com leitor de codigo de barra, e inserir modificacoes.', 'Resolvido', '1 - ivanrank', '2021-01-14 00:00:00'),
(11, 'Bras papelaria', 'Bras papelaria', 'nd', 'cliente nao consegue encontar NCM do produto. ', 'Resolvido', '1 - ivanrank', '2021-01-14 00:00:00'),
(12, 'Carol', 'Gol tintas', 'nd', 'Isntalacao certificado digital', 'Resolvido', '1 - ivanrank', '2021-01-14 00:00:00'),
(13, 'Jeferson', 'Fibra forte', '62 99221 5057', 'Verificar precos na frente de caixa por f10 para aparecer os 2 valores. com desconto e o sem acima de X unidades. Agendar implementacao.', 'Resolvido', '1 - ivanrank', '2021-01-14 00:00:00'),
(14, 'Zico ', 'Levis', 'Nd', 'Dúvida a respeito de estoque congelado e estoque atual.', 'Resolvido', '1 - ivanrank', '2021-01-14 00:00:00'),
(15, 'Ester ', 'Faiska auto eletrica', 'nd', 'Emissao de cupom em contingencia e código de NCM estava errado para uma porca', 'Resolvido', '1 - ivanrank', '2021-01-15 00:00:00'),
(16, 'Isabela', 'Neo gas', 'nd', 'Erro na emissao de uma nota, cfop nao salva e erro na entrada de uma nota, fala que cnpj nao existe.', 'Resolvido', '1 - ivanrank', '2021-01-15 00:00:00'),
(17, 'Bianca ', 'Elos calcados', 'nd', 'Pedir para a Antonia retornar sem falta', 'Resolvido', '1 - ivanrank', '2021-01-15 00:00:00'),
(18, 'Leocides', 'sole', 'nd', 'Troca de computadores e instalacao do sistema', 'Resolvido', '1 - ivanrank', '2021-01-16 00:00:00'),
(19, 'Brilha forte', 'Brilha forte', 'nd', 'Instalacao de uma impressora fiscal apÃ³s formatacao do PC', 'Resolvido', '1 - ivanrank', '2021-01-18 00:00:00'),
(20, 'Divanio', 'Construcasa', 'nd', 'Auxilio na geracao do xml e atualizacao de sistema.', 'Resolvido', '1 - ivanrank', '2021-01-18 00:00:00'),
(21, 'Brilha forte', 'Brilha forte ', 'nd', 'caminho de salvar o xml nao estava correto, por isso nao finalizava as compras.', 'Resolvido', '1 - ivanrank', '2021-01-18 00:00:00'),
(22, 'Junior', 'Valadares', 'nd', 'Impressora não estava funcionando. ', 'Resolvido', '1 - ivanrank', '2021-01-19 00:00:00'),
(23, 'maria ', 'comando diesel', 'nd', 'caminho bd invalido', 'Resolvido', '1 - ivanrank', '2021-01-19 00:00:00'),
(24, 'Duca ', 'Levis', 'nd', 'Auxilio no fechamento de uma pre venda cancelada antriormente', 'Resolvido', '1 - ivanrank', '2021-01-19 00:00:00'),
(25, 'michele', 'V8', 'nd', 'Devolucaoo de mercadoria auxilio', 'Resolvido', '1 - ivanrank', '2021-01-19 00:00:00'),
(26, 'Gol tintas', 'Gol tintas', 'nd', 'Duvida se tem como abrir a versÃ£o DOS do sistema antigo', 'Resolvido', '1 - ivanrank', '2021-01-19 00:00:00'),
(27, 'Michele', 'Araguafer', 'nd', 'Alguns computadores nao estao funcionando apos atualizacao', 'Resolvido', '1 - ivanrank', '2021-01-19 00:00:00'),
(28, 'marilia', 'TAFF', 'nd', 'Devolucao de apenas 1 produto para fornecedor de uma nota, e entrada de nota fiscal', 'Resolvido', '1 - ivanrank', '2021-01-19 00:00:00'),
(29, 'Thais', 'Brilha forte', 'nd', 'Erro CFOP na hora de cadastrar', 'Resolvido', '1 - ivanrank', '2021-01-19 00:00:00'),
(30, 'maria', 'comando diesel', 'nd', 'auxilio para cancelar nota  de venda no caixa', 'Resolvido', '1 - ivanrank', '2021-01-19 00:00:00'),
(32, 'Vitor', 'Capital diesel', 'nd', 'Solicitou habilitacao do sistema', 'Resolvido', '1 - ivanrank', '2021-01-20 08:22:05'),
(33, 'Thais', 'brilha fort', 'nd', 'config impressora', 'Resolvido', '1 - ivanrank', '2021-01-20 11:45:04'),
(34, 'Marcio ', 'WALFER', 'nd', 'Falha na conexao com o sistema da casa das ferramentas', 'Resolvido', '1 - ivanrank', '2021-01-20 11:45:47'),
(35, 'Ester ', 'Faiska auto eletrica', 'nd', 'Codigo ncm vazio', 'Resolvido', '1 - ivanrank', '2021-01-20 11:46:23'),
(36, 'Michele ', 'v8', '33512039', 'Referencia camisa polo', 'Resolvido', '1 - ivanrank', '2021-01-20 14:02:41'),
(37, 'Levis', 'Levis', '33121396', 'Atualizacao somente da levis', 'Resolvido', '1 - ivanrank', '2021-01-20 14:54:00'),
(38, 'Stefane ', 'visuarte', '33127600', 'sistema nÃÂÃÂ£o funciona, paulo esta indo verificar', 'Resolvido', '1 - ivanrank', '2021-01-20 14:56:41'),
(39, 'Michele', 'Pf norte', '33132056', 'Sistema nao abre', 'Resolvido', '1 - ivanrank', '2021-01-20 14:59:34'),
(40, 'Maria', 'Fenix', 'nd', 'Duvida a respeito de xml', 'Resolvido', '1 - ivanrank', '2021-01-20 15:51:21'),
(41, 'Jordana ', 'Levis', 'nd', 'Atualizacao que o paulo fez nao funcionou', 'Resolvido', '1 - ivanrank', '2021-01-20 15:54:36'),
(42, 'MAGDA', 'MAGDA MODAS', '92032739', 'PEDIR PAULO PARA RETORNAR', 'Resolvido', '1 - ivanrank', '2021-01-20 16:13:47'),
(43, 'Bianca ', 'CSI', 'nd', 'CANCELAMENTO DE NOTAS FISCAIS POR FORA E DENTRO DO CAIXA', 'Resolvido', '1 - ivanrank', '2021-01-20 16:38:09'),
(44, 'Vanessa', 'Bras papelaria', 'nd', 'Cliente esta reclamando que sistema esta muito lento apos a atualizacao', 'Resolvido', '1 - ivanrank', '2021-01-20 17:49:34'),
(45, 'Elizeu', 'Faíska', 'nd', 'Auxilio pendrive e realização do beckup', 'Resolvido', '1 - ivanrank', '2021-01-21 08:35:22'),
(46, 'Martin', 'Fenix', ' 63 99308781', 'Solicitou auxilio para cadastrar uma nota fiscal de entrada', 'Resolvido', '1 - ivanrank', '2021-01-21 08:43:30'),
(48, 'Magda ', 'Magda modas', 'nd', 'Auxilio na exclusão de grade de estoque', 'Resolvido', '1 - ivanrank', '2021-01-21 13:45:58'),
(49, 'Josiane', 'Unifrios', '984366789', 'A cliente fez vendas para reduzir o estoque, porém ficou negativo.', 'Resolvido', '1 - ivanrank', '2021-01-21 14:07:58'),
(50, 'Mateus', 'Gol tintas', 'nd', 'Cfop invalido ', 'Resolvido', '1 - ivanrank', '2021-01-21 14:35:42'),
(51, 'Marcelo ', 'Construcasa', '33131983', 'Problema relacionado a senha de usuario, ficou de me retornar', 'Outro', '1 - ivanrank', '2021-01-21 14:59:27'),
(52, 'Jeferson', '62992215057', 'nd', 'Auxilio em emissão de nota fiscal com cupom em contingencia', 'Resolvido', '1 - ivanrank', '2021-01-21 15:53:55'),
(53, 'Thamires', 'Campo forte', 'nd', 'nota de devolução', 'Resolvido', '1 - ivanrank', '2021-01-21 16:06:54'),
(54, 'Paula ', 'Bonafid', 'nd', 'aumentar juros ao mes boleto', 'Resolvido', '1 - ivanrank', '2021-01-21 17:07:20'),
(55, 'Marcio ', 'Valfer', '63 992445059', 'Instalação do programa', 'Outro', '1 - ivanrank', '2021-01-22 08:36:48'),
(56, 'cleu', 'União distribuidora', 'nd', 'Auxilio cadastrar permissão para cadastrar fabricante', 'Resolvido', '1 - ivanrank', '2021-01-22 09:44:52'),
(57, 'Michele', 'V8', 'nd', 'Atualizar sistema da empresa. 1 computador local', 'Resolvido', '1 - ivanrank', '2021-01-22 11:31:15'),
(58, 'Magda ', 'MAGDA MODAS', 'nd', 'Auxilio com balanço de estoque', 'Resolvido', '1 - ivanrank', '2021-01-22 14:01:47'),
(59, 'Michele', 'V8', 'nd', 'Atualização com correção para os produtos com letra minuscula', 'Resolvido', '1 - ivanrank', '2021-01-22 14:02:35'),
(60, 'Paula', 'Bonafid', 'nd', 'Auxilio com balanço de estoque', 'Resolvido', '1 - ivanrank', '2021-01-22 15:02:22'),
(61, 'Elaine', 'SOS borracheiro', 'nd', 'Solicitou segmentação de material retido e tributado, habilitar para segmentar a nota', 'Em aberto', '1 - ivanrank', '2021-01-22 16:30:30'),
(62, 'iasmin', 'Brilha forte ', 'nd', 'a preencher', 'Resolvido', '1 - ivanrank', '2021-01-22 16:36:55'),
(63, 'Evercino', 'Valadares', 'nd', 'Instalação de certificado digital', 'Resolvido', '1 - ivanrank', '2021-01-22 17:02:59'),
(64, 'Pamela', 'Brilha forte', '62 996858072', 'orientação sobre impressora', 'Resolvido', '1 - ivanrank', '2021-01-23 11:00:53'),
(65, 'Rosa', 'Casa da borracha', 'nd', 'Auxilio emissao de nota', 'Resolvido', '1 - ivanrank', '2021-01-23 11:27:10'),
(66, 'ana ', 'Reviva', 'nd', 'Iventario, contador pediu para adicionar \r\nPeriodo: mes 12\r\nlayout: 15\r\npelo speed\r\n\r\n\r\nrealizar atualização e corrigir os ncms', 'Resolvido', '1 - ivanrank', '2021-01-25 09:43:12'),
(67, 'Salomão', 'Macvel', 'nd', 'Configuração de impressora', 'Resolvido', '1 - ivanrank', '2021-01-25 13:32:54'),
(68, 'Magda', 'Magda Modas', 'nd', 'Auxilio com balanço de produtos', 'Resolvido', '1 - ivanrank', '2021-01-25 13:33:29'),
(69, 'Marilia', 'Marilia', 'nd', 'Problema com Duplicata', 'Resolvido', '1 - ivanrank', '2021-01-25 13:34:04'),
(70, 'Dora', 'Construfacil', 'nd', 'Envio do inventario para contador', 'Resolvido', '1 - ivanrank', '2021-01-26 10:28:48'),
(71, 'Tamires', 'TAFF', '62 3945 0700', 'sistema precisa de habilitação', 'Resolvido', '1 - ivanrank', '2021-01-28 08:54:09'),
(72, 'Duca', 'Levis', 'nd', 'Mensagem de pagamento atrasado ', 'Resolvido', '1 - ivanrank', '2021-01-28 15:22:01'),
(73, 'Robes', 'comercial sto antonio', 'nd', 'Auxilio no inventario:\r\n\r\nTributados = 108 671,57\r\nSubstituição = 20 218,25\r\nIsento = 185,00\r\n', 'Resolvido', '1 - ivanrank', '2021-01-28 15:23:32'),
(74, 'Martin', 'Fenix auto peças', 'nd', 'Auxilio no cadastro de produtos', 'Resolvido', '1 - ivanrank', '2021-01-28 16:27:21'),
(75, 'Andreina', 'Açofer', 'nd', 'Duplicata gerada e quitada por cadastro errado .', 'Resolvido', '1 - ivanrank', '2021-01-29 08:32:30'),
(76, 'Bianca', 'Elos calçados', 'nd', 'Auxilio com emissão de nota de devolução', 'Resolvido', '1 - ivanrank', '2021-01-29 10:16:52'),
(77, 'Flávia', 'Bio extratus', 'nd', 'Auxílio em modificação de juros do boleto', 'Resolvido', '1 - ivanrank', '2021-01-29 10:18:58'),
(78, 'Leandro', 'Valadares', 'nd', 'Erro com nota fiscal', 'Resolvido', '1 - ivanrank', '2021-01-29 14:59:43'),
(79, 'Sonia', 'solê', 'nd', 'Auxílio com métodos de pagto', 'Resolvido', '1 - ivanrank', '2021-01-29 15:31:28'),
(80, 'Marilia', 'TAFF', 'nd', 'Conta paga para fornecedor não está aparecendo em relatório', 'Em aberto', '1 - ivanrank', '2021-01-29 16:40:27'),
(81, 'Duca', 'Levis', 'nd', 'auxilio com devolução', 'Resolvido', '1 - ivanrank', '2021-01-30 10:54:47'),
(82, 'Josilane', 'forte eletro', 'nd', 'Atualização de sistema', 'Resolvido', '1 - ivanrank', '2021-02-01 09:27:07'),
(83, 'Wilson', 'Maqpeças', 'nd', 'Boleto puxa endereço de cadastro no lugar do endereço de cobrança', 'Em aberto', '1 - ivanrank', '2021-02-01 10:04:51'),
(84, 'thaisa', 'Vila encanto', 'nd', 'Pedir para o paulo ligar', 'Em aberto', '1 - ivanrank', '2021-02-01 10:10:24'),
(85, 'Larissa', 'JB materiais elétricos', 'nd', 'Sistema não carregava telas da pré-venda', 'Resolvido', '1 - ivanrank', '2021-02-01 10:22:55');

--
-- Índices para tabelas despejadas
--

--
-- Índices para tabela `atendimentos_suporte`
--
ALTER TABLE `atendimentos_suporte`
  ADD PRIMARY KEY (`id_atend`);

--
-- AUTO_INCREMENT de tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `atendimentos_suporte`
--
ALTER TABLE `atendimentos_suporte`
  MODIFY `id_atend` int(32) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=86;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
